package com.humatraders.pos;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Build;
import android.webkit.JavascriptInterface;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;
import android.util.Base64;

public class PrinterBridge {
    private final Activity activity;
    private BluetoothSocket socket;
    private OutputStream output;
    private volatile String status = "Printer not connected";
    private volatile boolean permissionReady = false;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    public PrinterBridge(Activity activity) { this.activity = activity; permissionReady = Build.VERSION.SDK_INT < 31 || activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED; }
    public void setPermissionReady(boolean ready) { permissionReady = ready; }

    @JavascriptInterface public synchronized boolean connectPrinter(String requestedName) {
        try {
            if (Build.VERSION.SDK_INT >= 31 && (!permissionReady || activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)) { status = "Nearby devices permission not granted. Allow Bluetooth permission and retry."; return false; }
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null) { status = "This Android device has no Bluetooth adapter."; return false; }
            if (!adapter.isEnabled()) { status = "Turn on Bluetooth in Android Settings first."; return false; }
            BluetoothDevice chosen = null;
            Set<BluetoothDevice> paired = adapter.getBondedDevices();
            for (BluetoothDevice d : paired) {
                String name = d.getName();
                if (name != null && (name.equalsIgnoreCase(requestedName) || name.equalsIgnoreCase("BPrinter050014") || name.toLowerCase().contains("bprinter"))) { chosen = d; break; }
            }
            if (chosen == null) { status = "Printer not paired. Pair BPrinter050014 in Android Bluetooth settings, then retry."; return false; }
            closeSocket();
            adapter.cancelDiscovery();
            socket = chosen.createRfcommSocketToServiceRecord(SPP_UUID);
            socket.connect();
            output = socket.getOutputStream();
            status = "Connected to " + chosen.getName() + " using Bluetooth Classic SPP.";
            return true;
        } catch (Exception e) { closeSocket(); status = "SPP connect error: " + e.getMessage(); return false; }
    }

    @JavascriptInterface public synchronized boolean printEscPos(String base64, String paperWidth) {
        try { ensureConnected(); byte[] data = Base64.decode(base64, Base64.DEFAULT); output.write(data); output.flush(); status = "ESC/POS data sent."; return true; }
        catch (Exception e) { status = "SPP print error: " + e.getMessage(); return false; }
    }

    // Unicode receipt path: render Android text (including Devanagari when the device font supports it) as ESC/POS raster graphics.
    @JavascriptInterface public synchronized boolean printTextRaster(String base64Utf8, String paperWidth) {
        try {
            ensureConnected();
            String text = new String(Base64.decode(base64Utf8, Base64.DEFAULT), java.nio.charset.StandardCharsets.UTF_8);
            int width = "80".equals(paperWidth) ? 576 : 384;
            int margin = 10, fontSize = "80".equals(paperWidth) ? 22 : 18, lineHeight = fontSize + 9;
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG); paint.setColor(android.graphics.Color.BLACK); paint.setTextSize(fontSize); paint.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
            java.util.ArrayList<String> lines = new java.util.ArrayList<>();
            for (String raw : text.split("\n", -1)) {
                if (raw.isEmpty()) { lines.add(""); continue; }
                StringBuilder line = new StringBuilder();
                for (int i = 0; i < raw.length(); i++) {
                    char c = raw.charAt(i); String candidate = line.toString() + c;
                    if (paint.measureText(candidate) > width - margin * 2 && line.length() > 0) { lines.add(line.toString()); line.setLength(0); }
                    line.append(c);
                }
                lines.add(line.toString());
            }
            int height = Math.max(lineHeight * 3, margin * 2 + lines.size() * lineHeight);
            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap); canvas.drawColor(android.graphics.Color.WHITE);
            float y = margin + fontSize;
            for (String line : lines) { canvas.drawText(line, margin, y, paint); y += lineHeight; }
            ByteArrayOutputStream raster = new ByteArrayOutputStream();
            raster.write(new byte[]{0x1B,0x40});
            int bytesPerRow = (width + 7) / 8;
            for (int top = 0; top < height; top += 24) {
                int sliceHeight = Math.min(24, height - top);
                raster.write(new byte[]{0x1D,0x76,0x30,0x00,(byte)(bytesPerRow & 0xff),(byte)((bytesPerRow >> 8)&0xff),(byte)(sliceHeight & 0xff),(byte)((sliceHeight >> 8)&0xff)});
                for (int yRow = 0; yRow < sliceHeight; yRow++) {
                    for (int xb = 0; xb < bytesPerRow; xb++) {
                        int b = 0;
                        for (int bit = 0; bit < 8; bit++) { int x = xb * 8 + bit; if (x < width && (bitmap.getPixel(x, top + yRow) & 0x00ffffff) < 0x00808080) b |= (0x80 >> bit); }
                        raster.write(b);
                    }
                }
            }
            raster.write(new byte[]{0x1B,0x64,0x03,0x1D,0x56,0x00});
            output.write(raster.toByteArray()); output.flush(); bitmap.recycle(); status = "Unicode raster receipt sent over SPP."; return true;
        } catch (Exception e) { status = "Unicode SPP print error: " + e.getMessage(); return false; }
    }

    @JavascriptInterface public synchronized void disconnect() { closeSocket(); status = "Disconnected"; }
    @JavascriptInterface public String getStatus() { return "{\"message\":\"" + status.replace("\"", "'") + "\"}"; }
    private void ensureConnected() throws Exception { if (socket == null || !socket.isConnected() || output == null) throw new Exception("Printer not connected. Tap Search & Connect."); }
    private void closeSocket() { try { if (output != null) output.close(); } catch (Exception ignored) {} try { if (socket != null) socket.close(); } catch (Exception ignored) {} output = null; socket = null; }
}
