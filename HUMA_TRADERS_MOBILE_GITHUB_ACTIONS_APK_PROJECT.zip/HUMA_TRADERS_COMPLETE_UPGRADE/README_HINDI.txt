HUMA TRADERS – HTML/PWA + Android Bluetooth Classic SPP project

FOLDER: pwa/
1. Upload the CONTENTS of pwa/ to your HTTPS hosting (GitHub Pages/Vercel).
2. Keep index.html, manifest.json, sw.js and assets/ in the same structure.
3. Existing local database key is preserved: huma_traders_pro_v1.
4. PWA browser printing: BLE only when a compatible writable GATT characteristic exists. Classic SPP direct printing is Android APK only.

FOLDER: android/
1. Install Android Studio (JDK 17 recommended).
2. Android Studio > Open > select this android/ folder.
3. Wait for Gradle sync. If prompted, install Android SDK Platform 35 and Build Tools.
4. On phone, pair printer in Android Settings > Bluetooth. Pairing name expected: BPrinter050014.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Install app-debug.apk. Allow Nearby devices/Bluetooth permission.
7. Open HUMA TRADERS > More > Bluetooth Thermal Printer > Search & Connect > Print test receipt.

DATA MIGRATION:
Before switching from the old PWA, use More > Download JSON backup. Install the APK, open it, then More > Restore JSON backup. The app DB key remains huma_traders_pro_v1, but Chrome PWA storage and Android WebView storage are separate containers. Never uninstall/clear the old PWA before verifying the restored data in the APK.

PRINTER NOTES:
- Android native bridge uses Bluetooth Classic RFCOMM SPP UUID 00001101-0000-1000-8000-00805F9B34FB.
- The APK connects to an already-paired printer; pair it first in Android Settings.
- Unicode receipt text is rendered to ESC/POS raster graphics using Android fonts. Actual Devanagari glyph quality depends on the printer resolution and model. Test on the physical printer.
- No APK has been compiled and no physical printer test has been performed in this environment. Source project only; build and test on Android Studio/device.
- No cloud sync is added. Business data remains local to each app installation.

EXISTING HTML FEATURES RETAINED from uploaded source: POS billing, product/category search, variants, barcode scan/input, stock, CSV product import/export, customers/Khata, suppliers, purchase entry and supplier bill upload/OCR workflow, held bills, sales/profit reports, CSV exports, settings, JSON backup/restore, PWA install support and thermal receipt preview.

BUILD APK USING ONLY YOUR MOBILE (GitHub Actions):
A. Extract this project ZIP on your phone.
B. Open your GitHub repository in Chrome and switch to Desktop site if needed.
C. Upload the android/ folder contents into a folder named android at repository root. Also upload .github/workflows/build-android-apk.yml to the exact path .github/workflows/build-android-apk.yml. GitHub mobile app may hide dot-folders; use Chrome Desktop site or GitHub web upload.
D. Open repository > Actions > "Build HUMA TRADERS Android APK" > Run workflow > Run workflow.
E. Wait for the workflow to finish with a green check. Open the completed run, scroll to Artifacts, download HUMA-TRADERS-debug-apk, and extract app-debug.apk.
F. Tap APK to install. If Android asks, allow Chrome/GitHub to install unknown apps. Then open app and grant Nearby devices permission.

IMPORTANT:
- This workflow builds a DEBUG APK; it is for your own installation/testing, not Play Store publishing.
- The current Android app loads its bundled android/app/src/main/assets/index.html. It does not automatically fetch the live GitHub Pages site. To update the app UI, update that asset too and rebuild.
- The Android source project and workflow have not been physically built/tested on your phone here. Check the Actions build result and test actual printing before using for business billing.
